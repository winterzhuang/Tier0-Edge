# Changelog

## 1.0.2

- update plugin's description and bump toolkit version

## 1.0.1

- add links at the plugin.jon pointing to the license and to the repo.

## 1.0.0

Golioth's WebSocket Data Source Plugin Launch

The main focus on this release is to launch the new websocket data source plugin for the Grafana Community.
